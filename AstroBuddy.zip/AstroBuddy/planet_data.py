import requests
from datetime import datetime
from typing import Dict, Optional, List
import json

class PlanetDataAPI:
    """Fetches real-time planet data from multiple astronomy APIs."""
    
    def __init__(self):
        self.visible_planets_api = "https://api.visibleplanets.dev/v3"
        self.cache = {}
        self.cache_timeout = 3600
        
    def get_visible_planets(self, latitude: float = 40.7128, longitude: float = -74.0060) -> Optional[Dict]:
        """
        Fetch currently visible planets using Visible Planets API.
        Default location: New York City
        """
        try:
            url = f"{self.visible_planets_api}?latitude={latitude}&longitude={longitude}&showCoords=true"
            response = requests.get(url, timeout=5)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            print(f"Error fetching visible planets: {e}")
            return None
    
    def get_planet_position(self, planet_name: str, latitude: float = 40.7128, longitude: float = -74.0060) -> Optional[Dict]:
        """Get specific planet's current position and visibility."""
        data = self.get_visible_planets(latitude, longitude)
        if not data or 'data' not in data:
            return None
        
        for planet in data['data']:
            if planet['name'].lower() == planet_name.lower():
                return planet
        return None
    
    def format_planet_status(self, planet_data: Dict) -> str:
        """Format planet data into readable status."""
        if not planet_data:
            return "Real-time data unavailable"
        
        status = []
        
        if planet_data.get('aboveHorizon'):
            status.append("🌟 **Currently Visible!**")
            if 'altitude' in planet_data and 'azimuth' in planet_data:
                status.append(f"📍 Position: {planet_data['altitude']:.1f}° altitude, {planet_data['azimuth']:.1f}° azimuth")
        else:
            status.append("🌑 Currently Below Horizon")
        
        if 'constellation' in planet_data:
            status.append(f"⭐ In constellation: {planet_data['constellation']}")
        
        if 'distanceFromEarth' in planet_data:
            distance = planet_data['distanceFromEarth']
            status.append(f"📏 Distance from Earth: {distance:,.0f} km")
        
        return "\n".join(status)
    
    def get_all_planets_status(self, latitude: float = 40.7128, longitude: float = -74.0060) -> Dict[str, Dict]:
        """Get status for all planets."""
        data = self.get_visible_planets(latitude, longitude)
        if not data or 'data' not in data:
            return {}
        
        planet_status = {}
        for planet in data['data']:
            planet_status[planet['name'].lower()] = planet
        
        return planet_status
    
    def is_planet_visible(self, planet_name: str, latitude: float = 40.7128, longitude: float = -74.0060) -> bool:
        """Check if a planet is currently visible in the sky."""
        planet_data = self.get_planet_position(planet_name, latitude, longitude)
        if planet_data:
            return planet_data.get('aboveHorizon', False)
        return False
    
    def get_planet_coordinates(self, planet_name: str, latitude: float = 40.7128, longitude: float = -74.0060) -> Optional[Dict]:
        """Get celestial coordinates for a planet."""
        planet_data = self.get_planet_position(planet_name, latitude, longitude)
        if not planet_data:
            return None
        
        coords = {
            'altitude': planet_data.get('altitude'),
            'azimuth': planet_data.get('azimuth'),
            'right_ascension': planet_data.get('rightAscension'),
            'declination': planet_data.get('declination'),
            'above_horizon': planet_data.get('aboveHorizon', False)
        }
        return coords

# Initialize global instance
planet_api = PlanetDataAPI()

# Static planet information (combined with real-time data)
PLANET_INFO = {
    "mercury": {
        "short": "Mercury is the smallest planet and closest to the Sun.",
        "fun": "A year on Mercury lasts only 88 Earth days!",
        "emoji": "☿️",
        "id": "199"
    },
    "venus": {
        "short": "Venus is the hottest planet in our solar system.",
        "fun": "Its surface temperature is hot enough to melt lead!",
        "emoji": "♀",
        "id": "299"
    },
    "earth": {
        "short": "Our home planet.",
        "fun": "71% covered in water and the only known planet with life.",
        "emoji": "🌍",
        "id": "399"
    },
    "mars": {
        "short": "Mars is the red planet.",
        "fun": "It has the tallest volcano in the solar system (Olympus Mons).",
        "emoji": "♂",
        "id": "499"
    },
    "jupiter": {
        "short": "Jupiter is the largest planet in our solar system.",
        "fun": "It has more than 80 moons and a Great Red Spot storm.",
        "emoji": "♃",
        "id": "599"
    },
    "saturn": {
        "short": "Saturn is famous for its beautiful ring system.",
        "fun": "Saturn's rings are made of billions of pieces of ice and rock!",
        "emoji": "♄",
        "id": "699"
    },
    "uranus": {
        "short": "Uranus rotates on its side, making it unique.",
        "fun": "It's the coldest planet in our solar system!",
        "emoji": "⛢",
        "id": "799"
    },
    "neptune": {
        "short": "Neptune is the windiest planet in our solar system.",
        "fun": "Winds on Neptune can reach speeds of 1,200 mph!",
        "emoji": "♆",
        "id": "899"
    }
}

def get_planet_data_combined(planet_name: str, latitude: float = 40.7128, longitude: float = -74.0060) -> Dict:
    """Combine static info with real-time data."""
    planet_name = planet_name.lower()
    
    result = {
        'name': planet_name.capitalize(),
        'static_info': PLANET_INFO.get(planet_name, {}),
        'real_time': None,
        'status': 'offline'
    }
    
    real_time_data = planet_api.get_planet_position(planet_name, latitude, longitude)
    if real_time_data:
        result['real_time'] = real_time_data
        result['status'] = 'live'
    
    return result
