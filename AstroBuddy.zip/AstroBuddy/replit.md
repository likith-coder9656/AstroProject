# Overview

AstroBuddy is an educational space exploration application that provides interactive learning about planets, space missions, and astronomical discoveries. The application uses Streamlit for its web interface and includes a knowledge base with information about planets in our solar system, historical space missions, NASA discoveries, and quiz questions for educational engagement.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: Streamlit-based web application
- **Rationale**: Streamlit provides rapid prototyping for data-driven applications with minimal frontend code, making it ideal for educational content delivery
- **UI Components**: Interactive elements for displaying planetary information, mission details, and quiz functionality

## Application Structure
- **Monolithic Design**: Single `app.py` file contains all application logic
- **Rationale**: Simple structure appropriate for educational applications with limited complexity
- **Knowledge Base**: In-memory dictionary structures (PLANETS, MISSIONS, NASA_DISCOVERIES, QUIZ_QUESTIONS)
- **Alternative Considered**: External database storage - rejected in favor of simplicity for static educational content

## Intent Classification System
- **Pattern**: Rule-based text classification using keyword matching
- **Purpose**: Routes user queries to appropriate response handlers (planet info, missions, discoveries, quiz)
- **Rationale**: Simple implementation suitable for limited domain scope; no ML required for predictable query patterns
- **Cons**: Limited flexibility for natural language variations

## Data Model
- **Planetary Information**: Each planet object contains:
  - Short description
  - Fun fact
  - Distance from sun (in kilometers)
  - Emoji representation
- **Mission Data**: Key-value pairs mapping mission names to descriptions
- **Quiz Structure**: Question objects with multiple choices, correct answers, and explanations

## Multi-Interface Support
- **Primary Interface**: Streamlit web UI
- **Alternative Interfaces**: CLI and Flask API support (based on template structure)
- **Rationale**: Flexible deployment options for different user contexts (web, terminal, API integration)

# External Dependencies

## Core Framework
- **Streamlit**: Web application framework for interactive Python applications
- **Purpose**: Primary UI framework for educational interface

## Python Standard Library
- **random**: Quiz question shuffling and randomization
- **base64**: Asset encoding (likely for embedding images)
- **pathlib**: File path handling for static assets
- **argparse**: CLI argument parsing (in template version)

## Web Framework (Optional)
- **Flask**: REST API interface support
- **Purpose**: Provides programmatic access to AstroBuddy functionality

## Asset Management
- **Static Assets**: Local file storage for educational content
- **Location**: `attached_assets/` directory for supplementary materials

## Deployment Platform
- **Replit**: Configured for one-click deployment
- **Rationale**: Zero-setup deployment for educational accessibility