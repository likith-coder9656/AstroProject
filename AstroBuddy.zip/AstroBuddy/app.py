import streamlit as st
import random
import base64
from pathlib import Path
from datetime import datetime
from planet_data import planet_api, get_planet_data_combined, PLANET_INFO
from planet_3d import create_3d_planet_model, create_solar_system_view
import plotly.graph_objects as go

# ----------------------
# Knowledge base
# ----------------------
PLANETS = {
    "mercury": {
        "short": "Mercury is the smallest planet and closest to the Sun.",
        "fun": "A year on Mercury lasts only 88 Earth days!",
        "distance_from_sun_km": 57909050,
        "emoji": "☿️"
    },
    "venus": {
        "short": "Venus is the hottest planet in our solar system.",
        "fun": "Its surface temperature is hot enough to melt lead!",
        "distance_from_sun_km": 108209475,
        "emoji": "♀"
    },
    "earth": {
        "short": "Our home planet.",
        "fun": "71% covered in water and the only known planet with life.",
        "distance_from_sun_km": 149598262,
        "emoji": "🌍"
    },
    "mars": {
        "short": "Mars is the red planet.",
        "fun": "It has the tallest volcano in the solar system (Olympus Mons).",
        "distance_from_sun_km": 227943824,
        "emoji": "♂"
    },
    "jupiter": {
        "short": "Jupiter is the largest planet in our solar system.",
        "fun": "It has more than 80 moons and a Great Red Spot storm.",
        "distance_from_sun_km": 778500000,
        "emoji": "♃"
    },
    "saturn": {
        "short": "Saturn is famous for its beautiful ring system.",
        "fun": "Saturn's rings are made of billions of pieces of ice and rock!",
        "distance_from_sun_km": 1434000000,
        "emoji": "♄"
    },
    "uranus": {
        "short": "Uranus rotates on its side, making it unique.",
        "fun": "It's the coldest planet in our solar system!",
        "distance_from_sun_km": 2872500000,
        "emoji": "⛢"
    },
    "neptune": {
        "short": "Neptune is the windiest planet in our solar system.",
        "fun": "Winds on Neptune can reach speeds of 1,200 mph!",
        "distance_from_sun_km": 4495000000,
        "emoji": "♆"
    }
}

MISSIONS = {
    "apollo": "Apollo missions landed humans on the Moon between 1969-1972.",
    "voyager": "Voyager missions explored the outer planets and continue traveling through interstellar space.",
    "curiosity": "Curiosity rover has been exploring Mars since 2012, searching for signs of past life.",
    "hubble": "Hubble Space Telescope has been observing the universe since 1990.",
    "james webb": "James Webb Space Telescope launched in 2021, the most powerful space telescope ever built.",
    "perseverance": "Perseverance rover landed on Mars in 2021, collecting samples for future return to Earth."
}

NASA_DISCOVERIES = [
    "🌟 Thousands of exoplanets discovered in the habitable zone",
    "🕳️ First image of a black hole shadow captured by Event Horizon Telescope",
    "💧 Evidence of liquid water on Mars",
    "🌙 Ice confirmed on the Moon's poles",
    "🪐 Complex organic molecules found on Saturn's moon Enceladus",
    "☄️ Successful asteroid sample return missions",
    "🌌 Detection of gravitational waves from colliding black holes",
    "🔭 James Webb captured the deepest image of the universe ever taken",
    "🌊 Subsurface ocean discovered on Jupiter's moon Europa"
]

QUIZ_QUESTIONS = [
    {
        "q": "Which planet is known as the Red Planet?", 
        "choices": ["Earth", "Mars", "Venus", "Jupiter"], 
        "answer": "Mars", 
        "explain": "Iron-rich dust on Mars' surface makes it appear red from space."
    },
    {
        "q": "Which planet is the largest in our solar system?", 
        "choices": ["Saturn", "Jupiter", "Neptune", "Earth"], 
        "answer": "Jupiter", 
        "explain": "Jupiter is more than twice as massive as all other planets combined."
    },
    {
        "q": "Which planet is closest to the Sun?", 
        "choices": ["Venus", "Earth", "Mercury", "Mars"], 
        "answer": "Mercury", 
        "explain": "Mercury orbits closest to the Sun at about 36 million miles away."
    },
    {
        "q": "Which NASA mission first landed humans on the Moon?", 
        "choices": ["Apollo 10", "Apollo 11", "Apollo 12", "Gemini 7"], 
        "answer": "Apollo 11", 
        "explain": "Apollo 11 landed on July 20, 1969, with Neil Armstrong and Buzz Aldrin."
    },
    {
        "q": "Which planet has the most moons?", 
        "choices": ["Jupiter", "Saturn", "Uranus", "Neptune"], 
        "answer": "Saturn", 
        "explain": "Saturn has over 140 known moons, more than any other planet!"
    },
    {
        "q": "What is the hottest planet in our solar system?", 
        "choices": ["Mercury", "Venus", "Mars", "Jupiter"], 
        "answer": "Venus", 
        "explain": "Venus is hotter than Mercury due to its thick atmosphere trapping heat."
    }
]

# ----------------------
# Helper functions
# ----------------------
def get_base64_image(image_path):
    """Convert image to base64 for CSS background."""
    try:
        with open(image_path, "rb") as image_file:
            encoded = base64.b64encode(image_file.read()).decode()
        return encoded
    except:
        return None

def classify_intent(user_text: str):
    """Classify user input to determine intent and extract relevant information."""
    text = (user_text or "").lower()
    
    if any(word in text for word in ["quiz", "test", "question", "game"]):
        return "quiz", {}
    
    if "distance" in text or "far" in text:
        for planet in PLANETS:
            if planet in text:
                return "distance", {"planet": planet}
    
    for planet in PLANETS:
        if planet in text:
            return "planet", {"planet": planet}
    
    for mission in MISSIONS:
        if mission in text:
            return "mission", {"mission": mission}
    
    if any(word in text for word in ["discover", "discovery", "found", "nasa", "space"]):
        return "discovery", {}
    
    return "unknown", {}

def answer_planet(key: str, latitude: float = 40.7128, longitude: float = -74.0060):
    """Return information about a planet with real-time data."""
    data = PLANETS.get(key.lower())
    if not data:
        available = ", ".join([p.capitalize() for p in PLANETS.keys()])
        return f"I don't have information about {key}. Try asking about: {available}!", None
    
    response = f"{data['emoji']} **{key.capitalize()}**: {data['short']} \n\n✨ **Fun fact**: {data['fun']}"
    
    real_time_data = planet_api.get_planet_position(key, latitude, longitude)
    
    return response, real_time_data

def answer_mission(key: str):
    """Return information about a space mission."""
    mission_info = MISSIONS.get(key.lower())
    if not mission_info:
        available = ", ".join([m.capitalize() for m in MISSIONS.keys()])
        return f"I don't have information about the {key} mission. Try asking about: {available}!"
    return f"🚀 **{key.capitalize()} Mission**: {mission_info}"

def answer_discovery():
    """Return a random NASA discovery."""
    return f"🔬 **NASA Discovery**: {random.choice(NASA_DISCOVERIES)}"

def get_distance_info(key: str):
    """Return distance information for a planet."""
    planet_data = PLANETS.get(key.lower())
    if not planet_data:
        return f"I don't have distance information for {key}."
    
    distance_km = planet_data['distance_from_sun_km']
    distance_miles = distance_km * 0.621371
    
    return f"📏 **{key.capitalize()}** is **{distance_km:,} km** ({distance_miles:,.0f} miles) from the Sun."

def evaluate_quiz_answer(question, user_choice):
    """Evaluate a quiz answer and return result with explanation."""
    correct = user_choice == question['answer']
    return correct, question['explain']

# ----------------------
# Streamlit App
# ----------------------
def main():
    st.set_page_config(
        page_title="🪐 AstroBuddy",
        page_icon="🪐",
        layout="wide",
        initial_sidebar_state="expanded"
    )
    
    # Load background image
    bg_image = get_base64_image("attached_assets/stock_images/deep_space_nebula_ga_4ff6b586.jpg")
    
    # Custom CSS with space theme
    st.markdown(f"""
        <style>
        /* Main background with space image */
        .stApp {{
            background-image: url("data:image/jpg;base64,{bg_image}");
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
        }}
        
        /* Glassmorphism effect for main content */
        .block-container {{
            background: rgba(10, 10, 30, 0.75);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 2rem;
            border: 1px solid rgba(255, 255, 255, 0.1);
        }}
        
        /* Sidebar styling */
        [data-testid="stSidebar"] {{
            background: rgba(15, 15, 40, 0.85);
            backdrop-filter: blur(15px);
            border-right: 2px solid rgba(138, 43, 226, 0.3);
        }}
        
        /* Headers with glow effect */
        h1, h2, h3 {{
            color: #fff;
            text-shadow: 0 0 20px rgba(138, 43, 226, 0.6);
        }}
        
        /* Input fields */
        .stTextInput > div > div > input {{
            background: rgba(30, 30, 60, 0.8);
            color: white;
            border: 2px solid rgba(138, 43, 226, 0.5);
            border-radius: 10px;
            transition: all 0.3s ease;
        }}
        
        .stTextInput > div > div > input:focus {{
            border-color: rgba(138, 43, 226, 1);
            box-shadow: 0 0 20px rgba(138, 43, 226, 0.5);
        }}
        
        /* Buttons with animation */
        .stButton > button {{
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 10px;
            padding: 0.5rem 1rem;
            font-weight: bold;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(138, 43, 226, 0.4);
        }}
        
        .stButton > button:hover {{
            transform: translateY(-2px);
            box-shadow: 0 6px 25px rgba(138, 43, 226, 0.6);
        }}
        
        /* Radio buttons */
        .stRadio > div {{
            background: rgba(30, 30, 60, 0.6);
            padding: 1rem;
            border-radius: 10px;
            border: 1px solid rgba(138, 43, 226, 0.3);
        }}
        
        /* Metric cards */
        [data-testid="stMetricValue"] {{
            color: #fff;
            font-size: 1.5rem;
            text-shadow: 0 0 10px rgba(138, 43, 226, 0.5);
        }}
        
        /* Success/Error messages */
        .stSuccess, .stError, .stInfo {{
            background: rgba(30, 30, 60, 0.8);
            border-radius: 10px;
            border-left: 4px solid;
        }}
        
        /* Markdown text */
        .stMarkdown {{
            color: rgba(255, 255, 255, 0.95);
        }}
        
        /* Divider */
        hr {{
            border-color: rgba(138, 43, 226, 0.3);
        }}
        
        /* Animation for planet buttons */
        @keyframes float {{
            0%, 100% {{ transform: translateY(0px); }}
            50% {{ transform: translateY(-10px); }}
        }}
        
        .planet-card {{
            animation: float 3s ease-in-out infinite;
        }}
        </style>
    """, unsafe_allow_html=True)
    
    # Header with animated title
    st.markdown("<h1 style='text-align: center; font-size: 3rem;'>🪐 AstroBuddy</h1>", unsafe_allow_html=True)
    st.markdown("<p style='text-align: center; font-size: 1.2rem; color: rgba(255,255,255,0.8);'>Your Interactive Space Learning Companion</p>", unsafe_allow_html=True)
    
    # Sidebar with interactive menu
    with st.sidebar:
        st.markdown("<h2 style='color: #8a2be2;'>🌟 Explore Space</h2>", unsafe_allow_html=True)
        
        st.markdown("### 📍 Your Location")
        st.caption("Set your location for real-time planet visibility")
        
        col_lat, col_lon = st.columns(2)
        with col_lat:
            user_lat = st.number_input("Latitude", value=40.7128, min_value=-90.0, max_value=90.0, step=0.1, format="%.4f")
        with col_lon:
            user_lon = st.number_input("Longitude", value=-74.0060, min_value=-180.0, max_value=180.0, step=0.1, format="%.4f")
        
        st.session_state.user_location = (user_lat, user_lon)
        
        st.markdown("---")
        st.markdown("### 🪐 Available Planets")
        for planet, data in PLANETS.items():
            if st.button(f"{data['emoji']} {planet.capitalize()}", key=f"btn_{planet}", use_container_width=True):
                st.session_state.last_query = f"Tell me about {planet}"
        
        st.markdown("---")
        st.markdown("### 🚀 Space Missions")
        mission_list = ["Apollo", "Voyager", "Curiosity", "Hubble", "James Webb", "Perseverance"]
        for mission in mission_list[:3]:
            st.markdown(f"• {mission}")
        
        st.markdown("---")
        st.markdown("### 💡 Quick Actions")
        if st.button("🎲 Random Discovery", use_container_width=True):
            st.session_state.last_query = "show discovery"
        
        if st.button("📚 Start Learning Quiz", use_container_width=True):
            st.session_state.last_query = "quiz"
        
        if st.button("🌌 View Solar System", use_container_width=True):
            st.session_state.show_solar_system = True
    
    # Show Solar System view if requested
    if st.session_state.get('show_solar_system', False):
        st.markdown("---")
        st.markdown("## 🌌 Solar System 3D View")
        
        col_close, _ = st.columns([1, 5])
        with col_close:
            if st.button("❌ Close View"):
                st.session_state.show_solar_system = False
                st.rerun()
        
        solar_system_fig = create_solar_system_view()
        st.plotly_chart(solar_system_fig, use_container_width=True)
        
        st.markdown("---")
        st.caption("💡 **Tip**: Drag to rotate • Scroll to zoom • The view shows relative positions of all planets in our solar system")
    
    # Main content area
    col1, col2 = st.columns([2, 1], gap="large")
    
    with col1:
        st.markdown("### 💬 Ask AstroBuddy Anything")
        
        # Get last query from session state or default
        default_query = st.session_state.get('last_query', '')
        
        user_question = st.text_input(
            "Type your space question:",
            value=default_query,
            placeholder="e.g., Tell me about Mars, start a quiz, show NASA discovery...",
            key="main_input"
        )
        
        # Clear the session state after using it
        if 'last_query' in st.session_state:
            del st.session_state.last_query
        
        if user_question:
            intent, metadata = classify_intent(user_question)
            
            # Get user location
            lat, lon = st.session_state.get('user_location', (40.7128, -74.0060))
            
            with st.container():
                if intent == "planet":
                    planet_info, real_time_data = answer_planet(metadata['planet'], lat, lon)
                    st.markdown(f"""
                        <div style='background: rgba(138, 43, 226, 0.1); padding: 1.5rem; border-radius: 15px; border-left: 4px solid #8a2be2;'>
                            {planet_info}
                        </div>
                    """, unsafe_allow_html=True)
                    
                    if real_time_data:
                        st.markdown("---")
                        st.markdown("### 🔴 Live Position Data")
                        
                        col_a, col_b = st.columns(2)
                        with col_a:
                            if real_time_data.get('aboveHorizon'):
                                st.success("✅ Currently Visible!")
                            else:
                                st.info("🌑 Below Horizon")
                        
                        with col_b:
                            if 'altitude' in real_time_data:
                                st.metric("Altitude", f"{real_time_data['altitude']:.1f}°")
                        
                        if 'azimuth' in real_time_data and 'constellation' in real_time_data:
                            col_c, col_d = st.columns(2)
                            with col_c:
                                st.metric("Azimuth", f"{real_time_data['azimuth']:.1f}°")
                            with col_d:
                                st.metric("Constellation", real_time_data['constellation'])
                        
                        st.caption(f"📡 Real-time data as of {datetime.now().strftime('%H:%M:%S UTC')}")
                    else:
                        st.warning("⚠️ Real-time data temporarily unavailable")
                    
                    # Add 3D planet model
                    st.markdown("---")
                    st.markdown("### 🌐 Interactive 3D Model")
                    planet_3d_model = create_3d_planet_model(metadata['planet'])
                    if planet_3d_model:
                        st.plotly_chart(planet_3d_model, use_container_width=True)
                    else:
                        st.error("Unable to load 3D model for this planet.")
                    
                elif intent == "mission":
                    mission_info = answer_mission(metadata['mission'])
                    st.markdown(f"""
                        <div style='background: rgba(30, 144, 255, 0.1); padding: 1.5rem; border-radius: 15px; border-left: 4px solid #1e90ff;'>
                            {mission_info}
                        </div>
                    """, unsafe_allow_html=True)
                    
                elif intent == "discovery":
                    discovery_info = answer_discovery()
                    st.markdown(f"""
                        <div style='background: rgba(255, 215, 0, 0.1); padding: 1.5rem; border-radius: 15px; border-left: 4px solid #ffd700;'>
                            {discovery_info}
                        </div>
                    """, unsafe_allow_html=True)
                    
                elif intent == "distance":
                    distance_info = get_distance_info(metadata['planet'])
                    st.markdown(f"""
                        <div style='background: rgba(0, 255, 127, 0.1); padding: 1.5rem; border-radius: 15px; border-left: 4px solid #00ff7f;'>
                            {distance_info}
                        </div>
                    """, unsafe_allow_html=True)
                    
                elif intent == "quiz":
                    st.markdown("🎯 **Quiz Time!** Check the quiz panel on the right →")
                    
                else:
                    st.info("""
                        🤔 I'm not sure what you're asking about. Try:
                        - **Planets**: Mercury, Venus, Earth, Mars, Jupiter, Saturn, Uranus, Neptune
                        - **Missions**: Apollo, Voyager, Curiosity, Hubble, James Webb, Perseverance
                        - **Discoveries**: NASA discoveries
                        - **Quiz**: Test your knowledge
                    """)

    with col2:
        st.markdown("### 🎯 Space Quiz Challenge")
        
        # Initialize score if not exists
        if 'quiz_score' not in st.session_state:
            st.session_state.quiz_score = 0
            st.session_state.quiz_total = 0
        
        # Display score
        if st.session_state.quiz_total > 0:
            accuracy = (st.session_state.quiz_score / st.session_state.quiz_total) * 100
            st.metric("Your Score", f"{st.session_state.quiz_score}/{st.session_state.quiz_total}", 
                     f"{accuracy:.0f}% Accuracy")
        
        if st.button("🎲 New Quiz Question", use_container_width=True):
            st.session_state.current_question = random.choice(QUIZ_QUESTIONS)
            st.session_state.quiz_answered = False
            st.session_state.show_explanation = False
        
        if 'current_question' in st.session_state:
            question = st.session_state.current_question
            
            st.markdown(f"**❓ {question['q']}**")
            
            user_choice = st.radio(
                "Choose your answer:",
                question['choices'],
                key="quiz_choice"
            )
            
            if st.button("✅ Submit Answer", use_container_width=True):
                correct, explanation = evaluate_quiz_answer(question, user_choice)
                st.session_state.quiz_answered = True
                st.session_state.show_explanation = True
                st.session_state.quiz_result = correct
                st.session_state.explanation = explanation
                st.session_state.quiz_total += 1
                if correct:
                    st.session_state.quiz_score += 1
                st.rerun()
            
            if st.session_state.get('show_explanation', False):
                if st.session_state.get('quiz_result', False):
                    st.success("🎉 Correct! Awesome!")
                else:
                    st.error("❌ Not quite right.")
                
                st.info(f"💡 {st.session_state.get('explanation', '')}")
                
                if st.button("➡️ Next Question", use_container_width=True):
                    st.session_state.current_question = random.choice(QUIZ_QUESTIONS)
                    st.session_state.quiz_answered = False
                    st.session_state.show_explanation = False
                    st.rerun()

    # Footer with animated facts
    st.markdown("---")
    st.markdown("### 🌌 Quick Space Facts")
    
    fact_cols = st.columns(4)
    
    facts = [
        ("🪐", "Planets in Solar System", "8", "Since 2006"),
        ("🌙", "Earth's Moon Distance", "384,400 km", "Average"),
        ("🚀", "Apollo Missions", "6 Landings", "1969-1972"),
        ("🔭", "Hubble Age", "34+ years", "Since 1990")
    ]
    
    for col, (emoji, label, value, delta) in zip(fact_cols, facts):
        with col:
            st.metric(f"{emoji} {label}", value, delta)

if __name__ == "__main__":
    main()
