import plotly.graph_objects as go
import numpy as np

# Planet color schemes and properties
PLANET_COLORS = {
    "mercury": {
        "color": "#8C7853",
        "size": 0.383,
        "name": "Mercury"
    },
    "venus": {
        "color": "#FFC649",
        "size": 0.949,
        "name": "Venus"
    },
    "earth": {
        "color": "#4A90E2",
        "size": 1.0,
        "name": "Earth"
    },
    "mars": {
        "color": "#CD5C5C",
        "size": 0.532,
        "name": "Mars"
    },
    "jupiter": {
        "color": "#DAA520",
        "size": 11.21,
        "name": "Jupiter"
    },
    "saturn": {
        "color": "#F4D03F",
        "size": 9.45,
        "name": "Saturn"
    },
    "uranus": {
        "color": "#4FD0E0",
        "size": 4.01,
        "name": "Uranus"
    },
    "neptune": {
        "color": "#4169E1",
        "size": 3.88,
        "name": "Neptune"
    }
}

def create_planet_sphere(u, v, radius=1.0):
    """Generate 3D sphere coordinates."""
    x = radius * np.outer(np.cos(u), np.sin(v))
    y = radius * np.outer(np.sin(u), np.sin(v))
    z = radius * np.outer(np.ones(np.size(u)), np.cos(v))
    return x, y, z

def create_saturn_ring(inner_radius=1.2, outer_radius=2.0, segments=50):
    """Create Saturn's ring system."""
    theta = np.linspace(0, 2*np.pi, segments)
    
    # Inner ring edge
    x_inner = inner_radius * np.cos(theta)
    y_inner = inner_radius * np.sin(theta)
    z_inner = np.zeros_like(theta)
    
    # Outer ring edge
    x_outer = outer_radius * np.cos(theta)
    y_outer = outer_radius * np.sin(theta)
    z_outer = np.zeros_like(theta)
    
    return x_inner, y_inner, z_inner, x_outer, y_outer, z_outer

def create_3d_planet_model(planet_name: str, show_rotation: bool = True):
    """
    Create an interactive 3D model of a planet.
    
    Args:
        planet_name: Name of the planet (lowercase)
        show_rotation: Whether to show rotation animation
    
    Returns:
        Plotly figure object
    """
    planet_name = planet_name.lower()
    
    if planet_name not in PLANET_COLORS:
        return None
    
    planet_info = PLANET_COLORS[planet_name]
    
    # Create sphere coordinates
    u = np.linspace(0, 2 * np.pi, 50)
    v = np.linspace(0, np.pi, 50)
    
    # Scale radius for visualization (normalize to Earth size for better viewing)
    display_radius = 1.0 if planet_info['size'] > 5 else planet_info['size']
    
    x, y, z = create_planet_sphere(u, v, display_radius)
    
    # Create the planet surface
    planet_surface = go.Surface(
        x=x, y=y, z=z,
        colorscale=[[0, planet_info['color']], [1, planet_info['color']]],
        showscale=False,
        name=planet_info['name'],
        hovertemplate=f"{planet_info['name']}<br>Relative Size: {planet_info['size']:.2f}x Earth<extra></extra>"
    )
    
    # Create figure
    fig = go.Figure(data=[planet_surface])
    
    # Add Saturn's rings if it's Saturn
    if planet_name == "saturn":
        x_inner, y_inner, z_inner, x_outer, y_outer, z_outer = create_saturn_ring(
            inner_radius=display_radius * 1.3,
            outer_radius=display_radius * 2.2
        )
        
        # Create ring mesh
        theta = np.linspace(0, 2*np.pi, 50)
        r = np.linspace(display_radius * 1.3, display_radius * 2.2, 20)
        theta_grid, r_grid = np.meshgrid(theta, r)
        
        x_ring = r_grid * np.cos(theta_grid)
        y_ring = r_grid * np.sin(theta_grid)
        z_ring = np.zeros_like(x_ring)
        
        ring = go.Surface(
            x=x_ring, y=y_ring, z=z_ring,
            colorscale=[[0, '#E8D5A0'], [1, '#F4E4C1']],
            opacity=0.6,
            showscale=False,
            name="Saturn's Rings",
            hovertemplate="Saturn's Rings<extra></extra>"
        )
        
        fig.add_trace(ring)
    
    # Update layout for better visualization
    fig.update_layout(
        title=dict(
            text=f"3D Model: {planet_info['name']}",
            font=dict(size=20, color='white'),
            x=0.5,
            xanchor='center'
        ),
        scene=dict(
            xaxis=dict(visible=False, range=[-3, 3]),
            yaxis=dict(visible=False, range=[-3, 3]),
            zaxis=dict(visible=False, range=[-3, 3]),
            bgcolor='rgba(0, 0, 0, 0)',
            camera=dict(
                eye=dict(x=1.5, y=1.5, z=1.2)
            ),
            aspectmode='cube'
        ),
        paper_bgcolor='rgba(0, 0, 0, 0)',
        plot_bgcolor='rgba(0, 0, 0, 0)',
        margin=dict(l=0, r=0, t=40, b=0),
        height=500,
        showlegend=False
    )
    
    return fig

def create_solar_system_view(highlight_planet: str = ""):
    """
    Create a 3D view of the solar system with all planets.
    
    Args:
        highlight_planet: Name of planet to highlight (optional)
    
    Returns:
        Plotly figure object
    """
    fig = go.Figure()
    
    # Planet distances from sun (in AU, scaled for visualization)
    planet_distances = {
        "mercury": 0.4,
        "venus": 0.7,
        "earth": 1.0,
        "mars": 1.5,
        "jupiter": 5.2,
        "saturn": 9.5,
        "uranus": 19.2,
        "neptune": 30.1
    }
    
    # Scale factor for visualization
    scale = 0.5
    
    # Add Sun at center
    sun = go.Scatter3d(
        x=[0], y=[0], z=[0],
        mode='markers',
        marker=dict(size=30, color='#FDB813', symbol='circle'),
        name='Sun',
        hovertemplate='Sun<extra></extra>'
    )
    fig.add_trace(sun)
    
    # Add each planet
    for planet, distance in planet_distances.items():
        planet_info = PLANET_COLORS[planet]
        
        # Random angle for planet position
        angle = np.random.uniform(0, 2*np.pi)
        x = distance * scale * np.cos(angle)
        y = distance * scale * np.sin(angle)
        z = 0
        
        # Determine size and opacity
        size = max(5, planet_info['size'] * 3)
        opacity = 1.0 if highlight_planet == planet else 0.7
        
        planet_marker = go.Scatter3d(
            x=[x], y=[y], z=[z],
            mode='markers+text',
            marker=dict(
                size=size,
                color=planet_info['color'],
                opacity=opacity,
                line=dict(width=2, color='white') if highlight_planet == planet else dict(width=0)
            ),
            text=planet_info['name'],
            textposition='top center',
            textfont=dict(color='white', size=10),
            name=planet_info['name'],
            hovertemplate=f"{planet_info['name']}<br>Distance: {distance} AU<extra></extra>"
        )
        fig.add_trace(planet_marker)
        
        # Add orbit path
        orbit_angles = np.linspace(0, 2*np.pi, 100)
        orbit_x = distance * scale * np.cos(orbit_angles)
        orbit_y = distance * scale * np.sin(orbit_angles)
        orbit_z = np.zeros_like(orbit_angles)
        
        orbit = go.Scatter3d(
            x=orbit_x, y=orbit_y, z=orbit_z,
            mode='lines',
            line=dict(color='rgba(255, 255, 255, 0.2)', width=1),
            showlegend=False,
            hoverinfo='skip'
        )
        fig.add_trace(orbit)
    
    # Update layout
    fig.update_layout(
        title=dict(
            text="Solar System View",
            font=dict(size=20, color='white'),
            x=0.5,
            xanchor='center'
        ),
        scene=dict(
            xaxis=dict(visible=False),
            yaxis=dict(visible=False),
            zaxis=dict(visible=False),
            bgcolor='rgba(0, 0, 0, 0.9)',
            camera=dict(eye=dict(x=0, y=0, z=2))
        ),
        paper_bgcolor='rgba(0, 0, 0, 0)',
        plot_bgcolor='rgba(0, 0, 0, 0)',
        margin=dict(l=0, r=0, t=40, b=0),
        height=600,
        showlegend=False
    )
    
    return fig
